package com.reelmonster.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView todayCountText;
    private TextView timeLostText;
    private TextView monsterQuoteText;
    private LinearLayout chartBarsContainer;
    private Button level1Btn;
    private Button level2Btn;
    private Button toggleOverlayBtn;
    private Button accessibilityBtn;

    private final BroadcastReceiver uiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refreshDashboard();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildDashboardUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(FloatingMonsterService.ACTION_UPDATE_MONSTER);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(uiReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(uiReceiver, filter);
        }
        refreshDashboard();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            unregisterReceiver(uiReceiver);
        } catch (Exception ignored) {}
    }

    private void buildDashboardUI() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.parseColor("#FFF8FA"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(36));

        // Top Header with Cute Monster Icon + Title
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_monster);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(54), dp(54));
        logoLp.rightMargin = dp(14);
        logo.setLayoutParams(logoLp);
        header.addView(logo);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        TextView appTitle = new TextView(this);
        appTitle.setText("Reel Monster");
        appTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        appTitle.setTypeface(Typeface.DEFAULT_BOLD);
        appTitle.setTextColor(Color.parseColor("#1A1D28"));

        TextView appSub = new TextView(this);
        appSub.setText("100% Offline • Floats on Instagram & YouTube");
        appSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        appSub.setTextColor(Color.parseColor("#6E7485"));

        titleCol.addView(appTitle);
        titleCol.addView(appSub);
        header.addView(titleCol);
        root.addView(header);

        // Main White Card (Matches Project 6 "Inside the app" card)
        LinearLayout mainCard = new LinearLayout(this);
        mainCard.setOrientation(LinearLayout.VERTICAL);
        mainCard.setPadding(dp(24), dp(24), dp(24), dp(24));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.WHITE);
        cardBg.setCornerRadius(dp(28));
        cardBg.setStroke(dp(3), Color.parseColor("#1A1D28"));
        mainCard.setBackground(cardBg);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        cardLp.topMargin = dp(22);
        mainCard.setLayoutParams(cardLp);

        TextView todayLabel = new TextView(this);
        todayLabel.setText("Today");
        todayLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        todayLabel.setTypeface(Typeface.DEFAULT_BOLD);
        todayLabel.setTextColor(Color.parseColor("#1A1D28"));
        mainCard.addView(todayLabel);

        todayCountText = new TextView(this);
        todayCountText.setText("0");
        todayCountText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 64);
        todayCountText.setTypeface(Typeface.DEFAULT_BOLD);
        todayCountText.setTextColor(Color.parseColor("#1A1D28"));
        todayCountText.setGravity(Gravity.CENTER_HORIZONTAL);
        mainCard.addView(todayCountText);

        timeLostText = new TextView(this);
        timeLostText.setText("reels • 0m lost");
        timeLostText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        timeLostText.setTypeface(Typeface.DEFAULT_BOLD);
        timeLostText.setTextColor(Color.parseColor("#6E7485"));
        timeLostText.setGravity(Gravity.CENTER_HORIZONTAL);
        mainCard.addView(timeLostText);

        // 7-Day Bar Chart Container
        chartBarsContainer = new LinearLayout(this);
        chartBarsContainer.setOrientation(LinearLayout.HORIZONTAL);
        chartBarsContainer.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams chartLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(150)
        );
        chartLp.topMargin = dp(24);
        chartBarsContainer.setLayoutParams(chartLp);
        mainCard.addView(chartBarsContainer);

        TextView last7Label = new TextView(this);
        last7Label.setText("Last 7 days");
        last7Label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        last7Label.setTypeface(Typeface.DEFAULT_BOLD);
        last7Label.setTextColor(Color.parseColor("#6E7485"));
        last7Label.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams l7Lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        l7Lp.topMargin = dp(10);
        last7Label.setLayoutParams(l7Lp);
        mainCard.addView(last7Label);

        // Funny Quote Box at bottom of card ("Burp. Your homework says hi.")
        monsterQuoteText = new TextView(this);
        monsterQuoteText.setText("Burp. Your homework says hi.");
        monsterQuoteText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        monsterQuoteText.setTypeface(Typeface.DEFAULT_BOLD);
        monsterQuoteText.setTextColor(Color.parseColor("#1A1D28"));
        monsterQuoteText.setGravity(Gravity.CENTER);
        monsterQuoteText.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable quoteBg = new GradientDrawable();
        quoteBg.setColor(Color.parseColor("#F1F3F6"));
        quoteBg.setCornerRadius(dp(16));
        monsterQuoteText.setBackground(quoteBg);
        LinearLayout.LayoutParams quoteLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        quoteLp.topMargin = dp(22);
        monsterQuoteText.setLayoutParams(quoteLp);
        mainCard.addView(monsterQuoteText);

        root.addView(mainCard);

        // Level Selector Section (Level 1 Manual vs Level 2 Automatic)
        TextView levelTitle = new TextView(this);
        levelTitle.setText("Choose Your Level");
        levelTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        levelTitle.setTypeface(Typeface.DEFAULT_BOLD);
        levelTitle.setTextColor(Color.parseColor("#1A1D28"));
        LinearLayout.LayoutParams ltLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        ltLp.topMargin = dp(24);
        ltLp.bottomMargin = dp(10);
        levelTitle.setLayoutParams(ltLp);
        root.addView(levelTitle);

        LinearLayout levelRow = new LinearLayout(this);
        levelRow.setOrientation(LinearLayout.HORIZONTAL);

        level1Btn = new Button(this);
        level1Btn.setText("Level 1: Manual
(Tap Bubble +1)");
        level1Btn.setAllCaps(false);
        LinearLayout.LayoutParams b1Lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        b1Lp.rightMargin = dp(8);
        level1Btn.setLayoutParams(b1Lp);
        level1Btn.setOnClickListener(v -> {
            ReelStorage.setLevel(this, 1);
            refreshDashboard();
            sendBroadcast(new Intent(FloatingMonsterService.ACTION_UPDATE_MONSTER));
        });

        level2Btn = new Button(this);
        level2Btn.setText("Level 2: Automatic
(Auto Scroll Count)");
        level2Btn.setAllCaps(false);
        LinearLayout.LayoutParams b2Lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        b2Lp.leftMargin = dp(8);
        level2Btn.setLayoutParams(b2Lp);
        level2Btn.setOnClickListener(v -> {
            ReelStorage.setLevel(this, 2);
            refreshDashboard();
            sendBroadcast(new Intent(FloatingMonsterService.ACTION_UPDATE_MONSTER));
        });

        levelRow.addView(level1Btn);
        levelRow.addView(level2Btn);
        root.addView(levelRow);

        // Action Buttons: Launch Floating Bubble, Enable Accessibility for Level 2, Manual +1 Test
        toggleOverlayBtn = new Button(this);
        toggleOverlayBtn.setAllCaps(false);
        toggleOverlayBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        toggleOverlayBtn.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams overlayLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        overlayLp.topMargin = dp(16);
        toggleOverlayBtn.setLayoutParams(overlayLp);
        toggleOverlayBtn.setOnClickListener(v -> handleOverlayToggle());
        root.addView(toggleOverlayBtn);

        accessibilityBtn = new Button(this);
        accessibilityBtn.setAllCaps(false);
        accessibilityBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        LinearLayout.LayoutParams accLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        accLp.topMargin = dp(10);
        accessibilityBtn.setLayoutParams(accLp);
        accessibilityBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(this, "Enable 'Reel Monster Auto-Counter (Level 2)' in Installed Apps", Toast.LENGTH_LONG).show();
        });
        root.addView(accessibilityBtn);

        // Quick Test +1 Button inside app
        Button testPlusBtn = new Button(this);
        testPlusBtn.setText("Feed Monster Now (+1 Reel)");
        testPlusBtn.setAllCaps(false);
        styleButton(testPlusBtn, "#FFE0EC", "#C2185B");
        LinearLayout.LayoutParams tpLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        tpLp.topMargin = dp(10);
        testPlusBtn.setLayoutParams(tpLp);
        testPlusBtn.setOnClickListener(v -> {
            ReelStorage.incrementTodayCount(this);
            refreshDashboard();
            sendBroadcast(new Intent(FloatingMonsterService.ACTION_UPDATE_MONSTER));
        });
        root.addView(testPlusBtn);

        scrollView.addView(root);
        setContentView(scrollView);
    }

    private void handleOverlayToggle() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName())
            );
            startActivity(intent);
            Toast.makeText(this, "Grant 'Display over other apps' to float Reel Monster!", Toast.LENGTH_LONG).show();
            return;
        }

        boolean currentlyEnabled = ReelStorage.isOverlayEnabled(this);
        Intent serviceIntent = new Intent(this, FloatingMonsterService.class);
        if (currentlyEnabled) {
            ReelStorage.setOverlayEnabled(this, false);
            stopService(serviceIntent);
        } else {
            ReelStorage.setOverlayEnabled(this, true);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        }
        refreshDashboard();
    }

    private void refreshDashboard() {
        int todayCount = ReelStorage.getTodayCount(this);
        int level = ReelStorage.getLevel(this);

        todayCountText.setText(String.valueOf(todayCount));
        timeLostText.setText("reels • " + ReelStorage.formatTimeLost(todayCount));
        monsterQuoteText.setText(ReelStorage.getMonsterLine(todayCount, level));

        // Style Level 1 vs Level 2 Buttons
        if (level == 1) {
            styleButton(level1Btn, "#C2185B", "#FFFFFF");
            styleButton(level2Btn, "#E8EAF0", "#1A1D28");
        } else {
            styleButton(level1Btn, "#E8EAF0", "#1A1D28");
            styleButton(level2Btn, "#C2185B", "#FFFFFF");
        }

        // Overlay status button
        boolean canOverlay = Settings.canDrawOverlays(this);
        boolean overlayActive = canOverlay && ReelStorage.isOverlayEnabled(this);
        if (!canOverlay) {
            toggleOverlayBtn.setText("1. Grant 'Display Over Other Apps' Permission");
            styleButton(toggleOverlayBtn, "#E9437A", "#FFFFFF");
        } else if (overlayActive) {
            toggleOverlayBtn.setText("Floating Monster Active (Tap to Hide)");
            styleButton(toggleOverlayBtn, "#1A1D28", "#FFFFFF");
        } else {
            toggleOverlayBtn.setText("Launch Floating Monster Bubble");
            styleButton(toggleOverlayBtn, "#E9437A", "#FFFFFF");
        }

        // Accessibility status button (needed for Level 2)
        boolean accEnabled = isAccessibilityServiceEnabled();
        if (accEnabled) {
            accessibilityBtn.setText("Level 2 Auto-Sensor: ENABLED ✓");
            styleButton(accessibilityBtn, "#D7F5E8", "#0F6E46");
        } else {
            accessibilityBtn.setText("2. Enable Level 2 Auto-Count (Accessibility)");
            styleButton(accessibilityBtn, "#FFF0C2", "#7A5200");
        }

        render7DayBars();
    }

    private void render7DayBars() {
        chartBarsContainer.removeAllViews();
        int[] counts = ReelStorage.getLast7DaysCounts(this);
        String[] labels = ReelStorage.getLast7DaysLabels();

        int max = 10;
        for (int c : counts) {
            if (c > max) max = c;
        }

        for (int i = 0; i < 7; i++) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            col.setLayoutParams(colLp);

            TextView valText = new TextView(this);
            valText.setText(String.valueOf(counts[i]));
            valText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            valText.setTextColor(Color.parseColor("#6E7485"));
            valText.setGravity(Gravity.CENTER);
            col.addView(valText);

            View bar = new View(this);
            float ratio = Math.max(0.12f, (float) counts[i] / (float) max);
            int barHeight = (int) (dp(95) * ratio);
            LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(dp(24), barHeight);
            barLp.topMargin = dp(4);
            barLp.bottomMargin = dp(6);
            bar.setLayoutParams(barLp);

            GradientDrawable barBg = new GradientDrawable();
            barBg.setColor(i == 6 ? Color.parseColor("#E9437A") : Color.parseColor("#F48FB1"));
            barBg.setCornerRadius(dp(8));
            bar.setBackground(barBg);
            col.addView(bar);

            TextView dayLabel = new TextView(this);
            dayLabel.setText(labels[i]);
            dayLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            dayLabel.setTypeface(i == 6 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            dayLabel.setTextColor(Color.parseColor("#1A1D28"));
            dayLabel.setGravity(Gravity.CENTER);
            col.addView(dayLabel);

            chartBarsContainer.addView(col);
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        String service = getPackageName() + "/" + ReelAccessibilityService.class.getCanonicalName();
        String enabledServices = Settings.Secure.getString(
            getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        if (enabledServices == null) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabledServices);
        while (splitter.hasNext()) {
            if (splitter.next().equalsIgnoreCase(service)) return true;
        }
        return false;
    }

    private void styleButton(Button btn, String bgHex, String fgHex) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(bgHex));
        bg.setCornerRadius(dp(14));
        btn.setBackground(bg);
        btn.setTextColor(Color.parseColor(fgHex));
        btn.setPadding(dp(14), dp(14), dp(14), dp(14));
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()
        );
    }
}
