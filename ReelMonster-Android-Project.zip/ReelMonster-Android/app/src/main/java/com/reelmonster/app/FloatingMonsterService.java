package com.reelmonster.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingMonsterService extends Service {
    public static final String ACTION_UPDATE_MONSTER = "com.reelmonster.app.UPDATE_MONSTER";
    public static final String EXTRA_SHOW_SPEECH = "extra_show_speech";
    private static final String CHANNEL_ID = "reel_monster_overlay_channel";

    private WindowManager windowManager;
    private LinearLayout rootBubbleLayout;
    private FrameLayout monsterContainer;
    private ImageView monsterIcon;
    private TextView counterBadge;
    private TextView speechBubble;
    private WindowManager.LayoutParams params;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean showSpeech = intent.getBooleanExtra(EXTRA_SHOW_SPEECH, true);
            refreshMonsterUI(showSpeech);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        startMonsterForeground();
        if (Settings.canDrawOverlays(this)) {
            createFloatingBubble();
        }
        IntentFilter filter = new IntentFilter(ACTION_UPDATE_MONSTER);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(updateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(updateReceiver, filter);
        }
    }

    private void startMonsterForeground() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Reel Monster Floating Bubble",
                NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);

        Notification notification = builder
            .setContentTitle("Reel Monster is awake")
            .setContentText("Today: " + ReelStorage.getTodayCount(this) + " reels (" + ReelStorage.formatTimeLost(ReelStorage.getTodayCount(this)) + ")")
            .setSmallIcon(R.drawable.ic_monster)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build();

        startForeground(1001, notification);
    }

    private void createFloatingBubble() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        rootBubbleLayout = new LinearLayout(this);
        rootBubbleLayout.setOrientation(LinearLayout.VERTICAL);
        rootBubbleLayout.setGravity(Gravity.START);

        monsterContainer = new FrameLayout(this);
        int baseSize = dp(68);
        LinearLayout.LayoutParams containerLp = new LinearLayout.LayoutParams(baseSize, baseSize);
        monsterContainer.setLayoutParams(containerLp);

        monsterIcon = new ImageView(this);
        monsterIcon.setImageResource(R.drawable.ic_monster);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        );
        monsterIcon.setLayoutParams(iconLp);
        monsterContainer.addView(monsterIcon);

        // Yellow Counter Pill Badge
        counterBadge = new TextView(this);
        counterBadge.setTextColor(Color.parseColor("#1A1D28"));
        counterBadge.setTypeface(Typeface.DEFAULT_BOLD);
        counterBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        counterBadge.setPadding(dp(8), dp(2), dp(8), dp(2));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#FFD54F"));
        badgeBg.setCornerRadius(dp(12));
        badgeBg.setStroke(dp(2), Color.parseColor("#1A1D28"));
        counterBadge.setBackground(badgeBg);

        FrameLayout.LayoutParams badgeLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM | Gravity.END
        );
        counterBadge.setLayoutParams(badgeLp);
        monsterContainer.addView(counterBadge);

        // White Speech Bubble below monster
        speechBubble = new TextView(this);
        speechBubble.setTextColor(Color.parseColor("#1A1D28"));
        speechBubble.setTypeface(Typeface.DEFAULT_BOLD);
        speechBubble.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        speechBubble.setPadding(dp(10), dp(6), dp(10), dp(6));
        speechBubble.setMaxWidth(dp(170));
        GradientDrawable speechBg = new GradientDrawable();
        speechBg.setColor(Color.WHITE);
        speechBg.setCornerRadius(dp(12));
        speechBg.setStroke(dp(2), Color.parseColor("#1A1D28"));
        speechBubble.setBackground(speechBg);

        LinearLayout.LayoutParams speechLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        speechLp.topMargin = dp(4);
        speechBubble.setLayoutParams(speechLp);

        rootBubbleLayout.addView(monsterContainer);
        rootBubbleLayout.addView(speechBubble);

        int layoutFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(18);
        params.y = dp(120);

        setupDragAndTapListeners();
        windowManager.addView(rootBubbleLayout, params);
        refreshMonsterUI(true);
    }

    private void setupDragAndTapListeners() {
        rootBubbleLayout.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private long touchStartTime;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        touchStartTime = System.currentTimeMillis();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                        if (windowManager != null && rootBubbleLayout != null) {
                            windowManager.updateViewLayout(rootBubbleLayout, params);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                        float dx = Math.abs(event.getRawX() - initialTouchX);
                        float dy = Math.abs(event.getRawY() - initialTouchY);
                        long duration = System.currentTimeMillis() - touchStartTime;
                        if (dx < dp(10) && dy < dp(10) && duration < 350) {
                            // Tapped! Increment counter (works in Level 1 Manual or manual boost in Level 2)
                            ReelStorage.incrementTodayCount(FloatingMonsterService.this);
                            refreshMonsterUI(true);
                            sendBroadcast(new Intent(ACTION_UPDATE_MONSTER));
                        }
                        return true;
                }
                return false;
            }
        });
    }

    public void refreshMonsterUI(boolean showSpeech) {
        if (rootBubbleLayout == null) return;
        int count = ReelStorage.getTodayCount(this);
        int level = ReelStorage.getLevel(this);

        counterBadge.setText(String.valueOf(count));
        speechBubble.setText(ReelStorage.getMonsterLine(count, level));
        speechBubble.setVisibility(showSpeech ? View.VISIBLE : View.VISIBLE);

        // Grow the monster visually as count rises!
        float scale = ReelStorage.getMonsterScale(count);
        int scaledPx = (int) (dp(66) * scale);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(scaledPx, scaledPx);
        monsterContainer.setLayoutParams(lp);

        // Chomp bounce animation
        monsterIcon.animate().scaleX(1.18f).scaleY(0.85f).setDuration(90).withEndAction(() ->
            monsterIcon.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120).start()
        ).start();

        if (windowManager != null) {
            windowManager.updateViewLayout(rootBubbleLayout, params);
        }
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()
        );
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        refreshMonsterUI(true);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(updateReceiver);
        } catch (Exception ignored) {}
        if (windowManager != null && rootBubbleLayout != null) {
            windowManager.removeView(rootBubbleLayout);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
