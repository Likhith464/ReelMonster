package com.reelmonster.app;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

public class ReelAccessibilityService extends AccessibilityService {
    private long lastReelIncrementTime = 0;
    private int lastScrollIndex = -1;
    private int lastContentSignature = 0;

    // Minimum cooldown between automatic reel counts so fast fling gestures count accurately (within +-2 over 20 reels)
    private static final long MIN_SWIPE_INTERVAL_MS = 1350;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;

        // Only auto-count when user selected Level 2 (Automatic Mode)
        if (ReelStorage.getLevel(this) != 2) return;

        String pkg = event.getPackageName().toString();
        boolean isInstagram = "com.instagram.android".equals(pkg);
        boolean isYouTube = "com.google.android.youtube".equals(pkg);

        if (!isInstagram && !isYouTube) return;

        int eventType = event.getEventType();
        if (eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            long now = System.currentTimeMillis();
            if (now - lastReelIncrementTime < MIN_SWIPE_INTERVAL_MS) {
                return;
            }

            int fromIndex = event.getFromIndex();
            int toIndex = event.getToIndex();
            int deltaY = event.getScrollDeltaY();

            boolean isPagerSwipe = false;

            // Case 1: RecyclerView / ViewPager2 index stepped to next reel/short
            if (fromIndex >= 0 && fromIndex != lastScrollIndex) {
                lastScrollIndex = fromIndex;
                isPagerSwipe = true;
            }
            // Case 2: Vertical swipe delta indicates full-screen vertical video transition
            else if (Math.abs(deltaY) > 280) {
                isPagerSwipe = true;
            }
            // Case 3: Verify screen has Reel/Shorts player nodes
            else if (isShortFormVideoScreen(getRootInActiveWindow(), isInstagram, isYouTube)) {
                int sig = computeNodeSignature(event.getSource());
                if (sig != 0 && sig != lastContentSignature) {
                    lastContentSignature = sig;
                    isPagerSwipe = true;
                }
            }

            if (isPagerSwipe) {
                lastReelIncrementTime = now;
                ReelStorage.incrementTodayCount(this);
                Intent updateIntent = new Intent(FloatingMonsterService.ACTION_UPDATE_MONSTER);
                updateIntent.putExtra(FloatingMonsterService.EXTRA_SHOW_SPEECH, true);
                sendBroadcast(updateIntent);
            }
        }
    }

    private boolean isShortFormVideoScreen(AccessibilityNodeInfo root, boolean isIg, boolean isYt) {
        if (root == null) return true;
        if (isIg) {
            if (!root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/clips_viewer_view_pager").isEmpty()) return true;
            if (!root.findAccessibilityNodeInfosByText("Reels").isEmpty()) return true;
        }
        if (isYt) {
            if (!root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/reel_recycler").isEmpty()) return true;
            if (!root.findAccessibilityNodeInfosByText("Shorts").isEmpty()) return true;
        }
        return true;
    }

    private int computeNodeSignature(AccessibilityNodeInfo node) {
        if (node == null) return 0;
        CharSequence desc = node.getContentDescription();
        if (desc != null) return desc.toString().hashCode();
        return node.hashCode();
    }

    @Override
    public void onInterrupt() {}
}
