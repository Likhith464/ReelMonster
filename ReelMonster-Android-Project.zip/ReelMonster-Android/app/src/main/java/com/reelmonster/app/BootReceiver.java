package com.reelmonster.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ( intent != null && (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) ||
             "android.intent.action.QUICKBOOT_POWERON".equals(intent.getAction())) ) {
            if (ReelStorage.isOverlayEnabled(context) && Settings.canDrawOverlays(context)) {
                Intent serviceIntent = new Intent(context, FloatingMonsterService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
            }
        }
    }
}
