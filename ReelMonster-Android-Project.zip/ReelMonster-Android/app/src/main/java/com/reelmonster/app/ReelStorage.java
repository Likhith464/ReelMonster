package com.reelmonster.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReelStorage {
    private static final String PREF_NAME = "reel_monster_prefs";
    private static final String KEY_MODE_LEVEL = "mode_level"; // 1 = Manual, 2 = Automatic
    private static final String KEY_OVERLAY_ENABLED = "overlay_enabled";
    private static final int AVG_REEL_SECONDS = 25;

    private static final String[] FUNNY_LINES = new String[]{
        "Tap me +1! Feed me a reel!",
        "Yum! Brain rot tastes like cotton candy.",
        "Crunch! Another 30 seconds vanished.",
        "Munch munch... didn't you say 'just 2 minutes'?",
        "Yum! Your evening tastes great.",
        "Burp. Your homework says hi.",
        "I'm getting huge! Keep scrolling, human!",
        "Slurp! Dopamine soup for dinner!",
        "Wait, what was 3 reels ago? Exactly.",
        "I am now 80% pure short-form video.",
        "Your thumb has a six-pack now.",
        "Nom nom! Tomorrow's sleep schedule is delicious!"
    };

    public static SharedPreferences getPrefs(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static String getTodayKey() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        return "count_" + sdf.format(new Date());
    }

    public static int getTodayCount(Context context) {
        return getPrefs(context).getInt(getTodayKey(), 0);
    }

    public static int incrementTodayCount(Context context) {
        SharedPreferences prefs = getPrefs(context);
        String key = getTodayKey();
        int next = prefs.getInt(key, 0) + 1;
        prefs.edit().putInt(key, next).commit(); // commit() guarantees disk persistence before reboot
        return next;
    }

    public static void resetTodayCount(Context context) {
        getPrefs(context).edit().putInt(getTodayKey(), 0).commit();
    }

    public static int getLevel(Context context) {
        return getPrefs(context).getInt(KEY_MODE_LEVEL, 1);
    }

    public static void setLevel(Context context, int level) {
        getPrefs(context).edit().putInt(KEY_MODE_LEVEL, level).commit();
    }

    public static boolean isOverlayEnabled(Context context) {
        return getPrefs(context).getBoolean(KEY_OVERLAY_ENABLED, false);
    }

    public static void setOverlayEnabled(Context context, boolean enabled) {
        getPrefs(context).edit().putBoolean(KEY_OVERLAY_ENABLED, enabled).commit();
    }

    public static int[] getLast7DaysCounts(Context context) {
        SharedPreferences prefs = getPrefs(context);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        int[] counts = new int[7];
        for (int i = 6; i >= 0; i--) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -i);
            String key = "count_" + sdf.format(cal.getTime());
            counts[6 - i] = prefs.getInt(key, 0);
        }
        return counts;
    }

    public static String[] getLast7DaysLabels() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEE", Locale.US);
        String[] labels = new String[7];
        for (int i = 6; i >= 0; i--) {
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_YEAR, -i);
            labels[6 - i] = sdf.format(cal.getTime());
        }
        return labels;
    }

    public static String formatTimeLost(int count) {
        int totalSeconds = count * AVG_REEL_SECONDS;
        int minutes = totalSeconds / 60;
        int hours = minutes / 60;
        int remMinutes = minutes % 60;
        if (hours > 0) {
            return remMinutes > 0 ? (hours + "h " + remMinutes + "m lost") : (hours + "h lost");
        } else if (minutes > 0) {
            return minutes + "m lost";
        } else {
            return totalSeconds + "s lost";
        }
    }

    public static String getMonsterLine(int count, int level) {
        if (count == 0) {
            return level == 1 ? "Tap me +1" : "Waiting for reels...";
        }
        if (count >= 120) return "Burp. Your homework says hi.";
        if (count >= 60) return "Yum! Your evening tastes great.";
        int idx = (count / 3) % FUNNY_LINES.length;
        return FUNNY_LINES[idx];
    }

    public static float getMonsterScale(int count) {
        // Grows smoothly from 1.0x up to 1.65x as reel count climbs
        float bonus = Math.min(0.65f, count * 0.008f);
        return 1.0f + bonus;
    }
}
